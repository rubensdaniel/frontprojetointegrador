
import { Routes, Route} from 'react-router-dom'
import Home from './Pages/Home'
import CadastroMercado from './Pages/Cadastro-mercado'
import CadastroProduto from './Pages/Cadastro-produto'
import Comparativos from './Pages/Comparativos'
import Login from './Pages/Login'
import Sobre from './Pages/Sobre'
import CadastroUsuario from './Pages/Cadastro-usuario'
import HistoricoProduto from './Pages/Historico-produto'
import AtualizacaoPreco from './Pages/Atualizacao-preco'
import AtualizacaoPrecoAdm from './Pages/Atualizacao-precoAdm'
import SugestaoProduto from './Pages/Sugestao-produtos'
import CadastroAdm from './Pages/Cadastro-adm'
import TermoUso from './Pages/Termo-de-uso'

function App() {

  return (
    <Routes>
      
      <Route path='/' element={<Home />}/>
      <Route path='/login' element={<Login />}/>
      <Route path='/cadastromercado' element={<CadastroMercado />}/>
      <Route path='/cadastroproduto' element={<CadastroProduto />}/>
      <Route path='/comparativos' element={<Comparativos />}/>
      <Route path='/sobre' element={<Sobre />}/>
      <Route path='/cadastrousuario' element={<CadastroUsuario />}/>
      <Route path='/hisotircoproduto' element={<HistoricoProduto />}/>
      <Route path='/atualizacaopreco' element={<AtualizacaoPreco />}/>
      <Route path='/atualizacaoprecoadm' element={<AtualizacaoPrecoAdm />}/>
      <Route path='/sugestaoproduto' element={<SugestaoProduto />}/>
      <Route path='/cadastroadm' element={<CadastroAdm />}/>
      <Route path='/sobre/termouso' element={<TermoUso />}></Route>


    </Routes>
  )
}

export default App
