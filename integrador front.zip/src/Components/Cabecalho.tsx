import { Link } from 'react-router-dom';
import '../Style/Cabecalho.css';

const Header = () => {
  return (
    <header className="header">
      <h1 className="logo">Meu Projeto</h1>
      <nav>
        <ul className="nav-list">
          <li><Link to="/login" className="nav-link">Login</Link></li>
          <li><Link to="/sobre" className="nav-link">Sobre</Link></li>
          <li><Link to="/comparativos" className="nav-link">Comparativos</Link></li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;

