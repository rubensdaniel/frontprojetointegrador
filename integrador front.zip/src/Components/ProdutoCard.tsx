import '../Style/Home.css';

type Props = {
    dados: {
    nome: string;
    marca: string;
    preco: string
    }
}

function ItemLista ({dados}: Props) {
    return(
        <div className='conteudoCard'>
            Nome: {dados.nome}
            <br />
            Marca: {dados.marca}
            <br />
            Preço: R${dados.preco}
        </div>
    )
}

export default ItemLista