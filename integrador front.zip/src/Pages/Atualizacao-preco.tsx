
function AtualizacaoPreco(){
    return(
        <div>
            Atualização de preço
        </div>
    )
}



export default AtualizacaoPreco;