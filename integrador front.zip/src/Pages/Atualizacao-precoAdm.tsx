
function AtualizacaoPrecoAdm(){
    return(
        <div>
            Atualização de preço dos ADM
        </div>
    )
}



export default AtualizacaoPrecoAdm;