
function CadastroAdm(){
    return(
        <div>
            Cadastro de ADM
        </div>
    )
}



export default CadastroAdm;