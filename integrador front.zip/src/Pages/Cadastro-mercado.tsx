
function CadastroMercado(){
    return(
        <div>
            Cadastro do Mercado
        </div>
    )
}



export default CadastroMercado