
function CadastroProduto(){
    return(
        <div>
            Cadastro do Produto
        </div>
    )
}



export default CadastroProduto