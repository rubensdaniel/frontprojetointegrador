
function Comparativos(){
    return(
        <div>
            Comparativos
        </div>
    )
}



export default Comparativos