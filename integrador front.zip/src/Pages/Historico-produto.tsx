
function HistoricoProduto(){
    return(
        <div>
            Histórico Produto
        </div>
    )
}



export default HistoricoProduto;