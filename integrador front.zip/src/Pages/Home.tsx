import Header from '../Components/Cabecalho';
import ItemLista from '../Components/ProdutoCard';
import '../Style/Home.css';

let produtos = [
  {nome: 'Arroz Branco', marca: 'Pateko', preco: '14,52' },
  {nome: 'Feijão carioca', marca: 'Feijão', preco: '8,52' },
  {nome: 'Farinha de trigo', marca: 'Dona Benta', preco: '6,00' },
  {nome: 'macarrão espaguete', marca: 'Macarrone', preco: '50,00' },
  {nome: 'macarrão espaguete', marca: 'Macarrone', preco: '50,00' },
  {nome: 'macarrão espaguete', marca: 'Macarrone', preco: '50,00' },
]

const Home = () => {
  return (
    <div className='home-container'>
   
      <Header />

      <div className='card'>
        {produtos.map((item, index)=>( 
          < ItemLista key={index} dados={item} /> 
        ))}
      </div>
      

    </div>
  );
};

export default Home;
