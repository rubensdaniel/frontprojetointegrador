
function SugestaoProduto(){
    return(
        <div>
            Sujestão de Produto
        </div>
    )
}



export default SugestaoProduto;